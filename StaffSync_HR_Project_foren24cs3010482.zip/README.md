# StaffSync — Modern HR Management System

A beginner-friendly HR dashboard built with HTML, CSS, JavaScript, Python Flask, and SQLite.

## Features
- Dashboard summary cards for employees, active staff, on-leave staff, and pending requests
- Employee directory with search
- Add and delete employee records
- Submit leave requests and approve/reject pending requests
- SQLite database created automatically
- JSON employee endpoint at `/api/employees`
- Responsive desktop/mobile layout

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this project folder.
3. Create and activate a virtual environment (recommended):

   **Windows**
   ```bash
   py -m venv .venv
   .venv\\Scripts\\activate
   ```

   **macOS/Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Start the app:
   ```bash
   python app.py
   ```
6. Open `http://127.0.0.1:5000` in your browser.

The SQLite database (`staffsync.db`) and sample employee records are created on first startup.

## Project structure

```text
staffsync_project/
├── app.py
├── requirements.txt
├── README.md
├── staffsync.db       # generated on first run
├── templates/
│   └── index.html
└── static/
    ├── style.css
    └── app.js
```

## API
- `GET /api/employees` — returns employee records as JSON.

## Important before real deployment
This is a learning/demo starter, not a production-ready HR platform. Before using real employee data, add authentication and role-based authorization, CSRF protection, secure secret management, audit logging, input validation, backups, and appropriate privacy controls. Do not expose employee data publicly. Replace Flask's development server with a production WSGI server for deployment.
