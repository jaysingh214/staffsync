function openModal(id){document.getElementById(id).classList.add('open')}
function closeModal(id){document.getElementById(id).classList.remove('open')}
function backdropClose(event,id){if(event.target.id===id)closeModal(id)}
function filterEmployees(){
  const q=document.getElementById('employeeSearch').value.toLowerCase().trim();
  document.querySelectorAll('#employeeTable tbody tr[data-search]').forEach(row=>{
    row.style.display=row.dataset.search.includes(q)?'':'none';
  });
}
const today = new Date();
const dateEl = document.getElementById('today');
if(dateEl) dateEl.textContent = today.toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric',year:'numeric'});
document.addEventListener('keydown',e=>{if(e.key==='Escape')document.querySelectorAll('.modal-backdrop.open').forEach(m=>m.classList.remove('open'))});
document.querySelectorAll('input[type="date"]').forEach(input=>input.addEventListener('change',()=>{
  const start=document.querySelector('input[name="start_date"]');
  const end=document.querySelector('input[name="end_date"]');
  if(start&&end&&start.value)end.min=start.value;
}));
