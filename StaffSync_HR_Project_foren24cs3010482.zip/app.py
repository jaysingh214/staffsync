from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import sqlite3
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-secret-key-before-deployment"
DB_PATH = Path(__file__).with_name("staffsync.db")

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            department TEXT NOT NULL,
            role TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Active'
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS leave_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_name TEXT NOT NULL,
            leave_type TEXT NOT NULL,
            start_date TEXT NOT NULL,
            end_date TEXT NOT NULL,
            reason TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'Pending'
        )""")
        count = conn.execute("SELECT COUNT(*) FROM employees").fetchone()[0]
        if count == 0:
            conn.executemany(
                "INSERT INTO employees (name,email,department,role,status) VALUES (?,?,?,?,?)",
                [
                    ("Aarav Sharma", "aarav@example.com", "Engineering", "Software Engineer", "Active"),
                    ("Meera Patel", "meera@example.com", "Human Resources", "HR Executive", "Active"),
                    ("Kabir Verma", "kabir@example.com", "Design", "UI/UX Designer", "Active"),
                    ("Ananya Singh", "ananya@example.com", "Finance", "Accountant", "On Leave"),
                ],
            )

@app.route("/")
def dashboard():
    with db() as conn:
        employees = conn.execute("SELECT * FROM employees ORDER BY id DESC").fetchall()
        leave_requests = conn.execute("SELECT * FROM leave_requests ORDER BY id DESC LIMIT 6").fetchall()
        total = conn.execute("SELECT COUNT(*) FROM employees").fetchone()[0]
        active = conn.execute("SELECT COUNT(*) FROM employees WHERE status='Active'").fetchone()[0]
        on_leave = conn.execute("SELECT COUNT(*) FROM employees WHERE status='On Leave'").fetchone()[0]
        pending = conn.execute("SELECT COUNT(*) FROM leave_requests WHERE status='Pending'").fetchone()[0]
    return render_template("index.html", employees=employees, leave_requests=leave_requests,
                           total=total, active=active, on_leave=on_leave, pending=pending)

@app.post("/employees/add")
def add_employee():
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip()
    department = request.form.get("department", "").strip()
    role = request.form.get("role", "").strip()
    if not all([name, email, department, role]):
        flash("Please complete every employee field.", "error")
        return redirect(url_for("dashboard"))
    try:
        with db() as conn:
            conn.execute("INSERT INTO employees (name,email,department,role) VALUES (?,?,?,?)",
                         (name, email, department, role))
        flash("Employee added successfully.", "success")
    except sqlite3.IntegrityError:
        flash("That email address is already registered.", "error")
    return redirect(url_for("dashboard"))

@app.post("/employees/<int:employee_id>/delete")
def delete_employee(employee_id):
    with db() as conn:
        conn.execute("DELETE FROM employees WHERE id=?", (employee_id,))
    flash("Employee record deleted.", "success")
    return redirect(url_for("dashboard"))

@app.post("/leave/apply")
def apply_leave():
    values = [request.form.get(k, "").strip() for k in
              ("employee_name", "leave_type", "start_date", "end_date", "reason")]
    if not all(values[:4]):
        flash("Please complete the required leave fields.", "error")
        return redirect(url_for("dashboard"))
    if values[2] > values[3]:
        flash("End date must be on or after the start date.", "error")
        return redirect(url_for("dashboard"))
    with db() as conn:
        conn.execute("""INSERT INTO leave_requests
            (employee_name,leave_type,start_date,end_date,reason) VALUES (?,?,?,?,?)""", values)
    flash("Leave request submitted.", "success")
    return redirect(url_for("dashboard"))

@app.post("/leave/<int:request_id>/<decision>")
def decide_leave(request_id, decision):
    if decision not in ("Approved", "Rejected"):
        return "Invalid decision", 400
    with db() as conn:
        conn.execute("UPDATE leave_requests SET status=? WHERE id=? AND status='Pending'",
                     (decision, request_id))
    flash(f"Leave request {decision.lower()}.", "success")
    return redirect(url_for("dashboard"))

@app.get("/api/employees")
def api_employees():
    with db() as conn:
        rows = conn.execute("SELECT id,name,email,department,role,status FROM employees ORDER BY name").fetchall()
    return jsonify([dict(row) for row in rows])

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
